import React, { useState, useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

export const ContactSection: React.FC = () => {
    const containerRef = useRef<HTMLDivElement>(null);
    const [status, setStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');

    useEffect(() => {
        if (!containerRef.current) return;

        gsap.from(containerRef.current, {
            y: 40,
            opacity: 0,
            duration: 0.8,
            ease: "power3.out",
            scrollTrigger: {
                trigger: containerRef.current,
                start: "top 80%",
            }
        });
    }, []);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        setStatus('loading');
        setTimeout(() => setStatus('success'), 2000); // simulation
    };

    const styles: Record<string, React.CSSProperties> = {
        section: {
            padding: 'var(--section-py) 0',
            textAlign: 'center',
            maxWidth: '700px',
            margin: '0 auto',
            display: 'flex',
            flexDirection: 'column',
            justifyContent: 'center',
            alignItems: 'center'
        },
        input: {
            width: '100%',
            background: 'rgba(255, 255, 255, 0.03)',
            border: '1px solid rgba(255, 255, 255, 0.1)',
            borderRadius: '8px',
            padding: '14px 18px',
            color: 'var(--text-primary)',
            fontSize: '16px',
            fontFamily: 'var(--font-body)',
            marginBottom: '16px',
            outline: 'none',
            transition: 'border-color 0.3s ease, box-shadow 0.3s ease'
        },
        button: {
            background: 'transparent',
            border: '1px solid var(--accent)',
            color: 'var(--accent)',
            padding: '14px 28px',
            borderRadius: '6px',
            fontSize: '16px',
            fontWeight: 600,
            cursor: 'pointer',
            transition: 'all 0.3s ease',
            marginTop: '10px'
        }
    };

    return (
        <section id="contact" style={styles.section} ref={containerRef}>
            <h2 className="section-title" style={{ justifyContent: 'center' }}>
                <span className="section-number">04.</span> Get In Touch
            </h2>
            <p style={{ color: 'var(--text-muted)', marginBottom: '30px', fontSize: '18px' }}>
                Although I'm not currently looking for new opportunities, my inbox is always open. Drop a message!
            </p>

            <form onSubmit={handleSubmit} style={{ width: '100%' }}>
                <input style={styles.input} type="text" placeholder="Your Name" required />
                <input style={styles.input} type="email" placeholder="Your Email" required />
                <textarea 
                    style={{ ...styles.input, resize: 'none' }} 
                    placeholder="Your Message" 
                    rows={6} 
                    required
                />
                <button type="submit" style={styles.button} className="btn-outline">
                    {status === 'loading' ? 'Sending...' : status === 'success' ? 'Message Sent!' : 'Send Message →'}
                </button>
            </form>

            <div style={{ display: 'flex', justifyContent: 'center', gap: '24px', marginTop: '60px' }}>
                {['GH', 'LI', 'TW', 'EM'].map(s => (
                    <a key={s} href="#" style={{ 
                        color: 'var(--text-muted)', 
                        fontSize: '22px', 
                        transition: 'all 0.3s ease' 
                    }} className="social-icon">{s}</a>
                ))}
            </div>

            <style>{`
                input:focus, textarea:focus {
                    border-color: var(--accent) !important;
                    box-shadow: 0 0 0 3px rgba(249, 115, 22, 0.15) !important;
                }
                .social-icon:hover {
                    color: var(--accent) !important;
                    transform: translateY(-5px);
                }
            `}</style>
        </section>
    );
};
