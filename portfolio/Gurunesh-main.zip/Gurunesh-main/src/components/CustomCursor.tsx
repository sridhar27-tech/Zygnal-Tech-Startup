import React, { useEffect, useRef } from 'react';
import { gsap } from 'gsap';

export const CustomCursor: React.FC = () => {
  const dotRef = useRef<HTMLDivElement>(null);
  const ringRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const onMouseMove = (e: MouseEvent) => {
      if (dotRef.current) {
        gsap.to(dotRef.current, { 
          x: e.clientX, 
          y: e.clientY, 
          duration: 0 
        });
      }
      if (ringRef.current) {
        gsap.to(ringRef.current, { 
          x: e.clientX, 
          y: e.clientY, 
          duration: 0.15 
        });
      }
    };

    const onMouseEnter = () => {
      if (ringRef.current) {
        gsap.to(ringRef.current, { 
          scale: 2.5, 
          opacity: 0.5, 
          duration: 0.3 
        });
      }
    };

    const onMouseLeave = () => {
      if (ringRef.current) {
        gsap.to(ringRef.current, { 
          scale: 1, 
          opacity: 1, 
          duration: 0.3 
        });
      }
    };

    window.addEventListener('mousemove', onMouseMove);

    const interactiveElements = document.querySelectorAll('a, button, .skill-card, .project-card');
    interactiveElements.forEach(el => {
      el.addEventListener('mouseenter', onMouseEnter);
      el.addEventListener('mouseleave', onMouseLeave);
    });

    return () => {
      window.removeEventListener('mousemove', onMouseMove);
      interactiveElements.forEach(el => {
        el.removeEventListener('mouseenter', onMouseEnter);
        el.removeEventListener('mouseleave', onMouseLeave);
      });
    };
  }, []);

  return (
    <>
      <div 
        ref={dotRef} 
        style={{
          position: 'fixed',
          pointerEvents: 'none',
          zIndex: 10000,
          borderRadius: '50%',
          transform: 'translate(-50%, -50%)',
          width: '8px',
          height: '8px',
          background: 'var(--accent)'
        }} 
      />
      <div 
        ref={ringRef} 
        style={{
          position: 'fixed',
          pointerEvents: 'none',
          zIndex: 10000,
          borderRadius: '50%',
          transform: 'translate(-50%, -50%)',
          width: '32px',
          height: '32px',
          border: '1.5px solid var(--accent)'
        }} 
      />
    </>
  );
};
