import React from 'react';

export const Footer: React.FC = () => {
    return (
        <footer style={{ 
            borderTop: '1px solid var(--border)', 
            padding: '40px 0', 
            textAlign: 'center',
            background: 'var(--bg-primary)'
        }}>
            <div style={{ display: 'flex', justifyContent: 'center', gap: '24px', marginBottom: '20px' }}>
               {/* Icon links here */}
            </div>
            <div style={{ fontSize: '14px', color: 'var(--text-muted)' }}>
                Designed & Built by Redoyanul Haque
            </div>
            <div style={{ fontSize: '13px', color: 'var(--text-muted)', marginTop: '5px' }}>
                © 2024 Redoyanul Haque. All rights reserved.
            </div>
        </footer>
    );
};
