import React, { useState, useEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

export const Navbar: React.FC = () => {
    const [isScrolled, setIsScrolled] = useState(false);
    const [isMenuOpen, setIsMenuOpen] = useState(false);

    useEffect(() => {
        const handleScroll = () => {
            if (window.scrollY > 80) {
                setIsScrolled(true);
            } else {
                setIsScrolled(false);
            }
        };

        window.addEventListener('scroll', handleScroll);
        return () => window.removeEventListener('scroll', handleScroll);
    }, []);

    const navLinks = [
        { name: 'About', href: '#about' },
        { name: 'Skills', href: '#skills' },
        { name: 'Projects', href: '#projects' },
        { name: 'Contact', href: '#contact' },
    ];

    const styles: Record<string, React.CSSProperties> = {
        nav: {
            position: 'fixed',
            top: 0,
            width: '100%',
            zIndex: 100,
            padding: isScrolled ? '15px 5%' : '30px 5%',
            background: isScrolled ? 'rgba(11, 13, 26, 0.9)' : 'transparent',
            backdropFilter: isScrolled ? 'blur(12px)' : 'none',
            borderBottom: isScrolled ? '1px solid var(--border)' : 'none',
            transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center'
        },
        logo: {
            fontFamily: 'var(--font-display)',
            fontWeight: 800,
            fontSize: '1.8rem',
            color: 'var(--accent)',
            cursor: 'pointer'
        },
        links: {
            display: 'flex',
            gap: '2.5rem',
            alignItems: 'center',
            fontSize: '14px',
            fontFamily: 'var(--font-mono)'
        },
        link: {
            color: 'var(--text-primary)',
            transition: 'color 0.3s ease',
            position: 'relative'
        },
        resumeBtn: {
            border: '1px solid var(--accent)',
            padding: '10px 22px',
            borderRadius: '6px',
            color: 'var(--accent)',
            fontWeight: 500,
            fontSize: '14px',
            transition: 'all 0.3s ease',
            marginLeft: '15px'
        }
    };

    return (
        <nav style={styles.nav}>
            <div style={styles.logo}>RH.</div>
            
            {/* Desktop Menu */}
            <div className="nav-desktop-menu" style={{ display: 'flex', alignItems: 'center' }}>
                <ul style={{ ...styles.links, listStyle: 'none' }}>
                    {navLinks.map((link, i) => (
                        <li key={link.name}>
                            <a 
                                href={link.href} 
                                style={styles.link}
                                className="nav-link"
                            >
                                <span style={{ color: 'var(--accent)', marginRight: '5px' }}>0{i+1}.</span> {link.name}
                            </a>
                        </li>
                    ))}
                </ul>
                <a href="#resume" style={styles.resumeBtn} className="btn-outline">Resume</a>
            </div>

            <style>{`
                .nav-link::after {
                    content: '';
                    position: absolute;
                    bottom: -5px;
                    left: 0;
                    width: 0;
                    height: 2px;
                    background: var(--accent);
                    transition: width 0.3s ease;
                }
                .nav-link:hover::after {
                    width: 100%;
                }
                .btn-outline:hover {
                    background: rgba(249, 115, 22, 0.12);
                    transform: translateY(-2px);
                }
                @media (max-width: 1024px) {
                    .nav-desktop-menu { display: none !important; }
                }
            `}</style>
        </nav>
    );
};
