import React, { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

export const AboutSection: React.FC = () => {
    const textRef = useRef<HTMLDivElement>(null);
    const imgRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        const textTl = gsap.timeline({
            scrollTrigger: {
                trigger: textRef.current,
                start: 'top 80%',
            }
        });

        textTl.from(textRef.current?.children || [], {
            x: 60,
            opacity: 0,
            stagger: 0.15,
            duration: 0.8,
            ease: 'power3.out'
        });

        gsap.from(imgRef.current, {
            x: -60,
            opacity: 0,
            duration: 1,
            ease: 'power3.out',
            scrollTrigger: {
                trigger: imgRef.current,
                start: 'top 80%',
            }
        });

        return () => {
            ScrollTrigger.getAll().forEach(st => st.kill());
        };
    }, []);

    const skills = ['Python', 'React', 'TypeScript', 'LangChain', 'FastAPI', 'AWS', 'Docker', 'PostgreSQL'];

    return (
        <section id="about" className="container" style={{ padding: 'var(--section-py) 0', display: 'grid', gridTemplateColumns: 'minmax(0, 1fr) minmax(0, 1.5fr)', gap: '80px', alignItems: 'center' }}>
            <div ref={imgRef} className="about-img-wrapper" style={{ position: 'relative', width: 'clamp(250px, 30vw, 400px)', height: 'clamp(300px, 40vw, 500px)', borderRadius: '4px', overflow: 'hidden' }}>
                <img 
                    src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=1000" 
                    alt="Redoyanul Haque" 
                    style={{ width: '100%', height: '100%', objectFit: 'cover', display: 'block', transition: 'transform 0.4s ease' }}
                />
                <div style={{ position: 'absolute', top: '16px', left: '16px', right: '-16px', bottom: '-16px', border: '2px solid var(--accent)', borderRadius: '4px', zIndex: -1 }}></div>
            </div>

            <div ref={textRef}>
                <h2 className="section-title">
                    <span className="section-number">01.</span> About Me
                </h2>
                <p style={{ color: 'var(--text-muted)', marginBottom: '20px', fontSize: '18px' }}>
                    Hi, I'm Redoyanul Haque, an AI Engineer and Full Stack Developer passionate about building intelligent systems and beautiful web experiences. 
                </p>
                <p style={{ color: 'var(--text-muted)', marginBottom: '25px', fontSize: '18px' }}>
                    I specialize in Python, LangChain, and FastAPI for AI backends and React, TypeScript for the frontend. I love solving complex problems and turning ideas into reality.
                </p>
                <p style={{ color: 'var(--text-primary)', marginBottom: '15px' }}>Here are some technologies I've been working with:</p>
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '10px' }}>
                    {skills.map(skill => (
                        <div key={skill} style={{ display: 'flex', alignItems: 'center', gap: '8px', color: 'var(--accent)', fontFamily: 'var(--font-mono)', fontSize: '14px' }}>
                            <span style={{ fontSize: '12px' }}>▹</span> {skill}
                        </div>
                    ))}
                </div>
            </div>

            <style>{`
                @media (max-width: 768px) {
                    section { grid-template-columns: 1fr !important; gap: 40px !important; text-align: center; }
                    .about-img-wrapper { margin: 0 auto; order: -1; }
                    .section-title { justify-content: center; }
                }
            `}</style>
        </section>
    );
};
