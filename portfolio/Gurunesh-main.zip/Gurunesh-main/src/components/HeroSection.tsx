import React, { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import SplitType from 'split-type';
import { useLoading } from '../context/LoadingProvider';
import { ThreeCanvas } from './ThreeCanvas';

export const HeroSection: React.FC = () => {
    const sectionRef = useRef<HTMLElement>(null);
    const titleRef = useRef<HTMLHeadingElement>(null);
    const subtitleRef = useRef<HTMLDivElement>(null);
    const bioRef = useRef<HTMLParagraphElement>(null);
    const ctaRef = useRef<HTMLDivElement>(null);
    const { isLoading } = useLoading();

    useEffect(() => {
        if (isLoading || !titleRef.current) return;

        const split = new SplitType(titleRef.current, { types: 'chars' });
        
        const tl = gsap.timeline({ delay: 0.2 });

        tl.from('.hero-label', {
            y: 20, 
            opacity: 0, 
            duration: 0.5, 
            ease: "power2.out"
        })
        .from(split.chars, {
            y: 100,
            opacity: 0,
            rotateX: -90,
            stagger: 0.03,
            duration: 0.8,
            ease: "back.out(2)"
        }, "-=0.3")
        .from(subtitleRef.current, {
            y: 30,
            opacity: 0,
            duration: 0.6,
            ease: "power2.out"
        }, "-=0.4")
        .from(bioRef.current, {
            y: 20,
            opacity: 0,
            duration: 0.5
        }, "-=0.3")
        .from(ctaRef.current?.children || [], {
            y: 20,
            opacity: 0,
            stagger: 0.15,
            duration: 0.5
        }, "-=0.2")
        .from('.hero-canvas-container', {
            scale: 0.8,
            opacity: 0,
            duration: 1,
            ease: "power3.out"
        }, 0.5);

        return () => {
           tl.kill();
           split.revert();
        };

    }, [isLoading]);

    return (
        <section ref={sectionRef} style={{ height: '100vh', display: 'grid', gridTemplateColumns: 'minmax(0, 1.2fr) 1fr', alignItems: 'center', padding: '0 5%' }}>
            <div className="hero-content" style={{ zIndex: 10 }}>
                <p className="hero-label" style={{ fontFamily: 'var(--font-mono)', color: 'var(--accent)', fontSize: '14px', marginBottom: '20px' }}>
                    Hello, I'm
                </p>
                <h1 
                    ref={titleRef} 
                    style={{ 
                        fontFamily: 'var(--font-display)', 
                        fontSize: 'clamp(40px, 8vw, 90px)', 
                        fontWeight: 800, 
                        lineHeight: 1.1,
                        marginBottom: '10px',
                        background: 'linear-gradient(135deg, #f97316, #a855f7)',
                        WebkitBackgroundClip: 'text',
                        WebkitTextFillColor: 'transparent',
                        backgroundClip: 'text'
                    }}
                >
                    REDOYANUL HAQUE
                </h1>
                <div 
                    ref={subtitleRef} 
                    style={{ 
                        fontSize: 'clamp(20px, 3vw, 40px)', 
                        fontWeight: 600, 
                        color: 'var(--text-secondary)',
                        marginBottom: '30px'
                    }}
                >
                    AI Engineer & Full Stack Developer
                </div>
                <p 
                    ref={bioRef} 
                    style={{ 
                        maxWidth: '540px', 
                        fontSize: '18px', 
                        color: 'var(--text-muted)', 
                        marginBottom: '40px' 
                    }}
                >
                    I build intelligent systems and beautiful web experiences. 
                    Specializing in Python AI backends and React TypeScript frontends.
                </p>
                <div ref={ctaRef} style={{ display: 'flex', gap: '20px' }}>
                    <a href="#projects" style={{ 
                        padding: '16px 30px', 
                        background: 'var(--accent)', 
                        color: '#0a0a0a', 
                        borderRadius: '6px', 
                        fontWeight: 600 
                    }}>View My Work</a>
                    <a href="https://github.com/red1-for-hek" style={{ 
                        padding: '16px 30px', 
                        border: '1px solid var(--accent)', 
                        color: 'var(--accent)', 
                        borderRadius: '6px', 
                        fontWeight: 600 
                    }}>GitHub</a>
                </div>
            </div>
            
            <div className="hero-canvas-container" style={{ position: 'relative', height: '100%', width: '100%' }}>
                <ThreeCanvas />
            </div>

            <style>{`
                @media (max-width: 1024px) {
                    section { grid-template-columns: 1fr !important; }
                    .hero-canvas-container { position: absolute !important; top: 0; left: 0; width: 100%; height: 100%; z-index: -1; opacity: 0.3 !important; }
                }
            `}</style>
        </section>
    );
};
