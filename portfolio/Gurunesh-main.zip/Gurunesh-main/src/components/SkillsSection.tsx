import React, { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const skillList = [
  { name: 'Python', icon: 'p' },
  { name: 'TypeScript', icon: 'ts' },
  { name: 'JavaScript', icon: 'js' },
  { name: 'React', icon: 're' },
  { name: 'HTML5', icon: 'h5' },
  { name: 'CSS3', icon: 'c3' },
  { name: 'FastAPI', icon: 'fa' },
  { name: 'Node.js', icon: 'nd' },
  { name: 'Express', icon: 'ex' },
  { name: 'LangChain', icon: 'lc' },
  { name: 'OpenAI', icon: 'ai' },
  { name: 'HuggingFace', icon: 'hf' },
  { name: 'PostgreSQL', icon: 'pg' },
  { name: 'MongoDB', icon: 'mg' },
  { name: 'Redis', icon: 'rd' },
  { name: 'Docker', icon: 'dk' },
  { name: 'AWS', icon: 'aw' },
  { name: 'GitHub Actions', icon: 'ga' },
  { name: 'Git', icon: 'gt' }
];

export const SkillsSection: React.FC = () => {
    const gridRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        if (!gridRef.current) return;

        gsap.from(gridRef.current.children, {
            y: 40,
            opacity: 0,
            stagger: 0.08,
            duration: 0.6,
            ease: "back.out(1.5)",
            scrollTrigger: {
                trigger: gridRef.current,
                start: "top 80%",
            }
        });
    }, []);

    return (
        <section id="skills" className="container" style={{ padding: 'var(--section-py) 0' }}>
            <h2 className="section-title">
                <span className="section-number">02.</span> My Tech Stack
            </h2>
            
            <div 
                ref={gridRef} 
                style={{ 
                    display: 'grid', 
                    gridTemplateColumns: 'repeat(auto-fill, minmax(130px, 1fr))', 
                    gap: '16px' 
                }}
            >
                {skillList.map(skill => (
                    <div 
                        key={skill.name} 
                        className="skill-card"
                        style={{
                            background: 'var(--bg-card)',
                            border: '1px solid var(--border)',
                            borderRadius: '12px',
                            padding: '24px 16px',
                            textAlign: 'center',
                            transition: 'all 0.3s ease',
                            backdropFilter: 'blur(10px)',
                            display: 'flex',
                            flexDirection: 'column',
                            alignItems: 'center',
                            gap: '12px',
                            cursor: 'default'
                        }}
                    >
                        <div style={{ color: 'var(--accent)', fontSize: '24px', fontWeight: '800', fontFamily: 'var(--font-mono)' }}>
                            {skill.icon}
                        </div>
                        <div style={{ fontSize: '14px', color: 'var(--text-secondary)' }}>
                            {skill.name}
                        </div>
                    </div>
                ))}
            </div>

            <style>{`
                .skill-card:hover {
                    transform: translateY(-8px);
                    border-color: var(--accent);
                    box-shadow: 0 0 24px rgba(249, 115, 22, 0.2);
                }
            `}</style>
        </section>
    );
};
