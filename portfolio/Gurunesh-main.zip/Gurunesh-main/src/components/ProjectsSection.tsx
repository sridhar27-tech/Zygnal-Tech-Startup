import React, { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const projects = [
    {
        title: 'AI Marketing Assistant',
        description: 'A platform that uses LangChain and OpenAI to generate marketing copy and analyze campaign data.',
        tech: ['Python', 'LangChain', 'OpenAI', 'Next.js'],
        github: '#',
        external: '#',
        image: 'https://images.unsplash.com/photo-1677442136019-21780ecad995?auto=format&fit=crop&q=80&w=1000'
    },
    {
        title: 'Crypto Portfolio Tracker',
        description: 'Real-time dashboard for tracking cryptocurrency assets with interactive charts and news feeds.',
        tech: ['React', 'TypeScript', 'Node.js', 'PostgreSQL'],
        github: '#',
        external: '#',
        image: 'https://images.unsplash.com/photo-1621761191319-c6fb62004040?auto=format&fit=crop&q=80&w=1000'
    },
    {
        title: 'E-commerce Engine',
        description: 'A headless e-commerce backend built with FastAPI and integrated with Stripe for seamless payments.',
        tech: ['FastAPI', 'Stripe', 'Redis', 'Docker'],
        github: '#',
        external: '#',
        image: 'https://images.unsplash.com/photo-1472851294608-062f824d29cc?auto=format&fit=crop&q=80&w=1000'
    }
];

export const ProjectsSection: React.FC = () => {
    const gridRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        if (!gridRef.current) return;

        gsap.from(gridRef.current.children, {
            y: 60,
            opacity: 0,
            stagger: 0.15,
            duration: 0.8,
            ease: "power3.out",
            scrollTrigger: {
                trigger: gridRef.current,
                start: "top 75%",
            }
        });
    }, []);

    return (
        <section id="projects" className="container" style={{ padding: 'var(--section-py) 0' }}>
            <h2 className="section-title">
                <span className="section-number">03.</span> Featured Projects
            </h2>

            <div 
                ref={gridRef} 
                style={{ 
                    display: 'grid', 
                    gridTemplateColumns: 'repeat(auto-fill, minmax(340px, 1fr))', 
                    gap: '24px' 
                }}
            >
                {projects.map(project => (
                    <div 
                        key={project.title} 
                        className="project-card"
                        style={{
                            background: 'rgba(16, 19, 42, 0.95)',
                            border: '1px solid var(--border)',
                            borderRadius: '12px',
                            overflow: 'hidden',
                            display: 'flex',
                            flexDirection: 'column',
                            transition: 'all 0.4s ease'
                        }}
                    >
                        <div className="project-img-wrapper" style={{ height: '200px', overflow: 'hidden' }}>
                            <img 
                                src={project.image} 
                                alt={project.title} 
                                style={{ width: '100%', height: '100%', objectFit: 'cover', transition: 'transform 0.5s ease' }} 
                            />
                        </div>
                        <div style={{ padding: '24px', flex: 1, display: 'flex', flexDirection: 'column', gap: '15px' }}>
                            <h3 style={{ fontSize: '1.5rem', fontWeight: 700, color: 'var(--text-primary)' }}>{project.title}</h3>
                            <p style={{ color: 'var(--text-muted)', fontSize: '15px', lineHeight: 1.6 }}>{project.description}</p>
                            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px', marginTop: 'auto' }}>
                                {project.tech.map(t => (
                                    <span key={t} style={{ 
                                        padding: '4px 10px', 
                                        background: 'rgba(249, 115, 22, 0.12)', 
                                        color: 'var(--accent)', 
                                        fontSize: '12px', 
                                        borderRadius: '4px',
                                        fontFamily: 'var(--font-mono)'
                                    }}>{t}</span>
                                ))}
                            </div>
                            <div style={{ display: 'flex', gap: '20px', marginTop: '10px' }}>
                                <a href={project.github} style={{ color: 'var(--text-muted)', fontSize: '20px' }}>GH</a>
                                <a href={project.external} style={{ color: 'var(--text-muted)', fontSize: '20px' }}>EXT</a>
                            </div>
                        </div>
                    </div>
                ))}
            </div>

            <style>{`
                .project-card:hover {
                    transform: translateY(-8px);
                    box-shadow: 0 20px 60px rgba(168, 85, 247, 0.15);
                }
                .project-card:hover img {
                    transform: scale(1.05);
                }
            `}</style>
        </section>
    );
};
