import React, { useRef, useEffect } from 'react';
import { initHeroScene } from '../utils/heroScene';

export const ThreeCanvas: React.FC = () => {
    const canvasRef = useRef<HTMLCanvasElement>(null);

    useEffect(() => {
        if (canvasRef.current) {
            const cleanup = initHeroScene(canvasRef.current);
            return cleanup;
        }
    }, []);

    return (
        <canvas 
            ref={canvasRef} 
            style={{ width: '100%', height: '100%', display: 'block' }} 
        />
    );
};
