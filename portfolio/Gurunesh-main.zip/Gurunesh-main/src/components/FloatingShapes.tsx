import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

export const FloatingShapes: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(60, window.innerWidth / window.innerHeight, 0.1, 100);
    camera.position.z = 12;

    const renderer = new THREE.WebGLRenderer({ canvas, alpha: true, antialias: true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.setSize(window.innerWidth, window.innerHeight);

    // Materials
    const orangeMat = new THREE.MeshToonMaterial({ color: 0xf97316, transparent: true, opacity: 0.5 });
    const violetMat = new THREE.MeshToonMaterial({ color: 0xa855f7, transparent: true, opacity: 0.4 });
    const roseMat = new THREE.MeshToonMaterial({ color: 0xf43f5e, transparent: true, opacity: 0.35 });
    const wireMat = new THREE.MeshBasicMaterial({ color: 0xf97316, wireframe: true, transparent: true, opacity: 0.15 });

    // Create floating shapes on the sides
    const shapes: THREE.Mesh[] = [];
    const shapeConfigs = [
      // Left side shapes
      { geo: new THREE.OctahedronGeometry(0.6, 0), mat: orangeMat, pos: [-7, 4, -2] },
      { geo: new THREE.TorusGeometry(0.5, 0.15, 16, 32), mat: violetMat, pos: [-6, -2, -3] },
      { geo: new THREE.IcosahedronGeometry(0.4, 0), mat: roseMat, pos: [-7.5, 0, -1] },
      { geo: new THREE.TetrahedronGeometry(0.5, 0), mat: orangeMat, pos: [-5.5, 6, -4] },
      { geo: new THREE.DodecahedronGeometry(0.35, 0), mat: violetMat, pos: [-6.5, -5, -2] },
      // Right side shapes
      { geo: new THREE.OctahedronGeometry(0.5, 0), mat: violetMat, pos: [7, 3, -3] },
      { geo: new THREE.TorusKnotGeometry(0.35, 0.1, 64, 8), mat: orangeMat, pos: [6.5, -3, -2] },
      { geo: new THREE.IcosahedronGeometry(0.55, 0), mat: roseMat, pos: [7.5, -1, -1] },
      { geo: new THREE.ConeGeometry(0.4, 0.8, 6), mat: violetMat, pos: [5.5, 5, -4] },
      { geo: new THREE.BoxGeometry(0.5, 0.5, 0.5), mat: roseMat, pos: [6, -6, -2] },
      // Large wire shapes far back
      { geo: new THREE.IcosahedronGeometry(2, 1), mat: wireMat, pos: [-4, 8, -8] },
      { geo: new THREE.OctahedronGeometry(1.8, 1), mat: wireMat, pos: [5, -8, -10] },
    ];

    shapeConfigs.forEach(cfg => {
      const mesh = new THREE.Mesh(cfg.geo, cfg.mat);
      mesh.position.set(cfg.pos[0], cfg.pos[1], cfg.pos[2]);
      mesh.rotation.set(Math.random() * Math.PI, Math.random() * Math.PI, 0);
      scene.add(mesh);
      shapes.push(mesh);
    });

    // Lighting
    const ambient = new THREE.AmbientLight(0xffffff, 0.4);
    scene.add(ambient);
    const dirLight = new THREE.DirectionalLight(0xf97316, 0.8);
    dirLight.position.set(5, 5, 5);
    scene.add(dirLight);

    // Scroll-driven animation via GSAP ScrollTrigger
    const scrollProxy = { progress: 0 };
    ScrollTrigger.create({
      trigger: document.body,
      start: 'top top',
      end: 'bottom bottom',
      scrub: 1,
      onUpdate: (self) => {
        scrollProxy.progress = self.progress;
      }
    });

    // Animation loop
    let animationId: number;
    const clock = new THREE.Clock();

    const tick = () => {
      const t = clock.getElapsedTime();
      const scrollP = scrollProxy.progress;

      shapes.forEach((mesh, i) => {
        // Idle rotation
        mesh.rotation.x += 0.003 * (i % 2 === 0 ? 1 : -1);
        mesh.rotation.y += 0.005 * (i % 3 === 0 ? 1 : -1);

        // Scroll-driven vertical movement (parallax layers)
        const speed = (i % 3 + 1) * 0.5;
        const baseY = shapeConfigs[i].pos[1];
        mesh.position.y = baseY - scrollP * speed * 8;

        // Gentle floating
        mesh.position.x = shapeConfigs[i].pos[0] + Math.sin(t * 0.3 + i) * 0.15;
      });

      renderer.render(scene, camera);
      animationId = requestAnimationFrame(tick);
    };
    tick();

    const onResize = () => {
      camera.aspect = window.innerWidth / window.innerHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(window.innerWidth, window.innerHeight);
    };
    window.addEventListener('resize', onResize);

    return () => {
      window.removeEventListener('resize', onResize);
      cancelAnimationFrame(animationId);
      ScrollTrigger.getAll().forEach(st => st.kill());
      renderer.dispose();
      scene.traverse((obj) => {
        if (obj instanceof THREE.Mesh) {
          obj.geometry.dispose();
          if (obj.material instanceof THREE.Material) obj.material.dispose();
        }
      });
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      style={{
        position: 'fixed',
        top: 0,
        left: 0,
        width: '100vw',
        height: '100vh',
        pointerEvents: 'none',
        zIndex: 1
      }}
    />
  );
};
