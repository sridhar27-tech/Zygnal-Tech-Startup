import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

export const revealSection = (selector: string, trigger: string, options = {}) => {
  gsap.from(selector, {
    y: 50,
    opacity: 0,
    duration: 0.9,
    ease: "power3.out",
    stagger: 0.1,
    scrollTrigger: {
      trigger,
      start: "top 75%",
      toggleActions: "play none none reverse",
      ...options
    }
  });
};
