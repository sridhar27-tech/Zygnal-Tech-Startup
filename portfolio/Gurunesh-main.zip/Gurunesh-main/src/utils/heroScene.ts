import * as THREE from 'three';

export const initHeroScene = (canvas: HTMLCanvasElement) => {
  const scene = new THREE.Scene();
  const rect = canvas.getBoundingClientRect();
  const camera = new THREE.PerspectiveCamera(50, rect.width / rect.height, 0.1, 100);
  camera.position.set(0, 1, 6);

  const renderer = new THREE.WebGLRenderer({ canvas, alpha: true, antialias: true });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.setSize(rect.width, rect.height);
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;

  // -- CARTOON DEVELOPER CHARACTER --
  const character = new THREE.Group();

  // Skin / shirt materials
  const skinMat = new THREE.MeshToonMaterial({ color: 0xffcc99 });
  const shirtMat = new THREE.MeshToonMaterial({ color: 0xa855f7 }); // violet
  const pantsMat = new THREE.MeshToonMaterial({ color: 0x1e293b });
  const shoeMat = new THREE.MeshToonMaterial({ color: 0xf97316 }); // orange accent
  const hairMat = new THREE.MeshToonMaterial({ color: 0x2d1b00 });
  const glassMat = new THREE.MeshToonMaterial({ color: 0x94a3b8, transparent: true, opacity: 0.6 });
  const frameMat = new THREE.MeshToonMaterial({ color: 0x1e1e2e });
  const screenMat = new THREE.MeshToonMaterial({ color: 0x38bdf8, emissive: 0x38bdf8, emissiveIntensity: 0.3 });

  // Head
  const headGeo = new THREE.SphereGeometry(0.55, 32, 32);
  const head = new THREE.Mesh(headGeo, skinMat);
  head.position.y = 2.5;
  head.castShadow = true;
  character.add(head);

  // Hair (top cap)
  const hairGeo = new THREE.SphereGeometry(0.58, 32, 16, 0, Math.PI * 2, 0, Math.PI * 0.55);
  const hair = new THREE.Mesh(hairGeo, hairMat);
  hair.position.y = 2.55;
  character.add(hair);

  // Eyes
  const eyeGeo = new THREE.SphereGeometry(0.08, 16, 16);
  const eyeWhiteMat = new THREE.MeshToonMaterial({ color: 0xffffff });
  const eyePupilMat = new THREE.MeshToonMaterial({ color: 0x1a1a2e });

  const eyeWhiteL = new THREE.Mesh(eyeGeo, eyeWhiteMat);
  eyeWhiteL.position.set(-0.18, 2.55, 0.45);
  eyeWhiteL.scale.set(1, 1.2, 0.6);
  character.add(eyeWhiteL);

  const eyeWhiteR = new THREE.Mesh(eyeGeo, eyeWhiteMat);
  eyeWhiteR.position.set(0.18, 2.55, 0.45);
  eyeWhiteR.scale.set(1, 1.2, 0.6);
  character.add(eyeWhiteR);

  const pupilGeo = new THREE.SphereGeometry(0.045, 16, 16);
  const pupilL = new THREE.Mesh(pupilGeo, eyePupilMat);
  pupilL.position.set(-0.18, 2.55, 0.52);
  character.add(pupilL);
  const pupilR = new THREE.Mesh(pupilGeo, eyePupilMat);
  pupilR.position.set(0.18, 2.55, 0.52);
  character.add(pupilR);

  // Glasses frames
  const glassFrameGeo = new THREE.TorusGeometry(0.14, 0.02, 8, 24);
  const glassL = new THREE.Mesh(glassFrameGeo, frameMat);
  glassL.position.set(-0.18, 2.55, 0.46);
  character.add(glassL);
  const glassR = new THREE.Mesh(glassFrameGeo, frameMat);
  glassR.position.set(0.18, 2.55, 0.46);
  character.add(glassR);

  // Glass bridge
  const bridgeGeo = new THREE.CylinderGeometry(0.015, 0.015, 0.12, 8);
  const bridge = new THREE.Mesh(bridgeGeo, frameMat);
  bridge.position.set(0, 2.57, 0.5);
  bridge.rotation.z = Math.PI / 2;
  character.add(bridge);

  // Mouth (small smile)
  const smileGeo = new THREE.TorusGeometry(0.1, 0.02, 8, 16, Math.PI);
  const smileMat = new THREE.MeshToonMaterial({ color: 0xe57373 });
  const smile = new THREE.Mesh(smileGeo, smileMat);
  smile.position.set(0, 2.32, 0.48);
  smile.rotation.x = Math.PI;
  character.add(smile);

  // Body / Torso (shirt)
  const torsoGeo = new THREE.CylinderGeometry(0.45, 0.4, 1.0, 16);
  const torso = new THREE.Mesh(torsoGeo, shirtMat);
  torso.position.y = 1.5;
  torso.castShadow = true;
  character.add(torso);

  // Arms
  const armGeo = new THREE.CapsuleGeometry(0.1, 0.6, 8, 16);
  const armL = new THREE.Mesh(armGeo, skinMat);
  armL.position.set(-0.6, 1.4, 0.2);
  armL.rotation.x = -0.4;
  armL.rotation.z = 0.3;
  character.add(armL);

  const armR = new THREE.Mesh(armGeo, skinMat);
  armR.position.set(0.6, 1.4, 0.2);
  armR.rotation.x = -0.4;
  armR.rotation.z = -0.3;
  character.add(armR);

  // Pants / legs
  const legGeo = new THREE.CapsuleGeometry(0.12, 0.5, 8, 16);
  const legL = new THREE.Mesh(legGeo, pantsMat);
  legL.position.set(-0.2, 0.55, 0);
  character.add(legL);
  const legR = new THREE.Mesh(legGeo, pantsMat);
  legR.position.set(0.2, 0.55, 0);
  character.add(legR);

  // Shoes
  const shoeGeo = new THREE.BoxGeometry(0.2, 0.1, 0.35);
  const shoeL = new THREE.Mesh(shoeGeo, shoeMat);
  shoeL.position.set(-0.2, 0.12, 0.05);
  character.add(shoeL);
  const shoeR = new THREE.Mesh(shoeGeo, shoeMat);
  shoeR.position.set(0.2, 0.12, 0.05);
  character.add(shoeR);

  // Laptop in front
  const laptopBase = new THREE.BoxGeometry(0.7, 0.04, 0.45);
  const laptopBaseMesh = new THREE.Mesh(laptopBase, frameMat);
  laptopBaseMesh.position.set(0, 1.22, 0.7);
  laptopBaseMesh.rotation.x = -0.1;
  character.add(laptopBaseMesh);

  const laptopScreen = new THREE.BoxGeometry(0.65, 0.45, 0.03);
  const laptopScreenMesh = new THREE.Mesh(laptopScreen, frameMat);
  laptopScreenMesh.position.set(0, 1.48, 0.92);
  laptopScreenMesh.rotation.x = -0.25;
  character.add(laptopScreenMesh);

  // Screen glow
  const screenFace = new THREE.PlaneGeometry(0.58, 0.38);
  const screenFaceMesh = new THREE.Mesh(screenFace, screenMat);
  screenFaceMesh.position.set(0, 1.48, 0.935);
  screenFaceMesh.rotation.x = -0.25;
  character.add(screenFaceMesh);

  // Center the character
  character.position.y = -1.3;
  scene.add(character);

  // -- LIGHTING --
  const ambientLight = new THREE.AmbientLight(0xffffff, 0.6);
  scene.add(ambientLight);

  const mainLight = new THREE.DirectionalLight(0xf97316, 1.2);
  mainLight.position.set(3, 5, 4);
  mainLight.castShadow = true;
  scene.add(mainLight);

  const fillLight = new THREE.DirectionalLight(0xa855f7, 0.5);
  fillLight.position.set(-3, 2, 2);
  scene.add(fillLight);

  const rimLight = new THREE.PointLight(0xf43f5e, 0.6, 10);
  rimLight.position.set(0, 3, -2);
  scene.add(rimLight);

  // -- MOUSE PARALLAX --
  let targetX = 0, targetY = 0;
  const onMouseMove = (e: MouseEvent) => {
    targetX = (e.clientX / window.innerWidth - 0.5) * 2;
    targetY = (e.clientY / window.innerHeight - 0.5) * 2;
  };
  window.addEventListener('mousemove', onMouseMove);

  // -- ANIMATE --
  let animationId: number;
  const clock = new THREE.Clock();

  const tick = () => {
    const t = clock.getElapsedTime();

    // Gentle idle bob
    character.position.y = -1.3 + Math.sin(t * 1.5) * 0.05;
    character.rotation.y += (targetX * 0.4 - character.rotation.y) * 0.03;
    character.rotation.x += (-targetY * 0.15 - character.rotation.x) * 0.03;

    // Breathing effect on torso
    torso.scale.x = 1 + Math.sin(t * 2) * 0.015;
    torso.scale.z = 1 + Math.sin(t * 2) * 0.015;

    // Screen color pulse
    const hue = (Math.sin(t * 0.5) * 0.5 + 0.5) * 0.15 + 0.5;
    screenMat.color.setHSL(hue, 0.7, 0.6);
    screenMat.emissive.setHSL(hue, 0.7, 0.3);

    renderer.render(scene, camera);
    animationId = requestAnimationFrame(tick);
  };
  tick();

  // -- RESIZE --
  const onResize = () => {
    const parent = canvas.parentElement;
    if (parent) {
      const { width, height } = parent.getBoundingClientRect();
      camera.aspect = width / height;
      camera.updateProjectionMatrix();
      renderer.setSize(width, height);
    }
  };
  window.addEventListener('resize', onResize);

  return () => {
    window.removeEventListener('mousemove', onMouseMove);
    window.removeEventListener('resize', onResize);
    cancelAnimationFrame(animationId);
    renderer.dispose();
    scene.traverse((obj) => {
      if (obj instanceof THREE.Mesh) {
        obj.geometry.dispose();
        if (obj.material instanceof THREE.Material) obj.material.dispose();
      }
    });
  };
};
