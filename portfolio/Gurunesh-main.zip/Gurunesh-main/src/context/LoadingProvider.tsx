import React, { createContext, useContext, useState, useEffect, useRef } from 'react';
import { gsap } from 'gsap';

interface LoadingContextType {
  isLoading: boolean;
  setIsLoading: (v: boolean) => void;
}

const LoadingContext = createContext<LoadingContextType>({
  isLoading: true,
  setIsLoading: () => {},
});

export const useLoading = () => useContext(LoadingContext);

export const LoadingProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isLoading, setIsLoading] = useState(true);
  const overlayRef = useRef<HTMLDivElement>(null);
  const monogramRef = useRef<SVGSVGElement>(null);
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    // Monogram entry animation
    if (monogramRef.current) {
        gsap.from(monogramRef.current, {
            scale: 0.5,
            opacity: 0,
            duration: 1.2,
            ease: "elastic.out(1, 0.5)"
        });
    }

    // Counter progress simulation
    const interval = setInterval(() => {
      setProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          return 100;
        }
        return prev + 1;
      });
    }, 20);

    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    if (progress === 100) {
      // Exit animation
      if (overlayRef.current) {
        gsap.to(overlayRef.current, {
           yPercent: -100,
           duration: 1,
           ease: "power4.inOut",
           onComplete: () => setIsLoading(false)
        });
      }
    }
  }, [progress]);

  return (
    <LoadingContext.Provider value={{ isLoading, setIsLoading }}>
      {isLoading && (
        <div 
          ref={overlayRef}
          style={{
            position: 'fixed',
            inset: 0,
            zIndex: 9999,
            background: '#0b0d1a',
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'center',
            gap: '20px'
          }}
        >
          <svg 
            ref={monogramRef}
            width="80" 
            height="80" 
            viewBox="0 0 100 100" 
            fill="none" 
            xmlns="http://www.w3.org/2000/svg"
          >
            <path 
                d="M30 20V80M30 20H60C70 20 70 40 60 40H30M60 40L80 80" 
                stroke="#f97316" 
                strokeWidth="4" 
                strokeLinecap="round" 
                strokeLinejoin="round"
            />
          </svg>
          <div style={{ color: '#f97316', fontFamily: 'var(--font-mono)', fontSize: '1.2rem' }}>
            {progress}%
          </div>
          <div style={{ 
            position: 'absolute', 
            bottom: 0, 
            left: 0, 
            height: '2px', 
            background: 'linear-gradient(90deg, #f97316, #a855f7)', 
            width: `${progress}%`,
            transition: 'width 0.1s linear'
          }} />
        </div>
      )}
      {children}
    </LoadingContext.Provider>
  );
};
