import React, { useEffect } from 'react';
import { gsap } from 'gsap';
import { LoadingProvider } from './context/LoadingProvider';
import { CustomCursor } from './components/CustomCursor';
import { FloatingShapes } from './components/FloatingShapes';
import { Navbar } from './components/Navbar';
import { HeroSection } from './components/HeroSection';
import { AboutSection } from './components/AboutSection';
import { SkillsSection } from './components/SkillsSection';
import { ProjectsSection } from './components/ProjectsSection';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import './styles/global.css';

const AppContent: React.FC = () => {
    useEffect(() => {
        let lenis: any = null;
        import('@studio-freight/lenis').then((mod) => {
            const Lenis = mod.default;
            lenis = new Lenis({ lerp: 0.1, duration: 1.2 });
            const ticker = (time: number) => lenis.raf(time * 1000);
            gsap.ticker.add(ticker);
            gsap.ticker.lagSmoothing(0);
        }).catch(() => {
            // Lenis not available, scroll normally
        });

        return () => {
            if (lenis) lenis.destroy();
        };
    }, []);

    return (
        <>
            <CustomCursor />
            <FloatingShapes />
            <div id="smooth-wrapper" style={{ position: 'relative', zIndex: 2 }}>
                <div id="smooth-content">
                    <Navbar />
                    <HeroSection />
                    <AboutSection />
                    <SkillsSection />
                    <ProjectsSection />
                    <ContactSection />
                    <Footer />
                </div>
            </div>
        </>
    );
};

const App: React.FC = () => {
    return (
        <LoadingProvider>
            <AppContent />
        </LoadingProvider>
    );
};

export default App;
