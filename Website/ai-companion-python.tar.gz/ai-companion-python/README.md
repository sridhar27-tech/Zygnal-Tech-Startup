# AI Companion - Python Flask Version

A conversational AI web application built with Python Flask to help address loneliness through meaningful conversations.

## 🎯 Features

- 🐍 **Python Powered**: Built with Flask web framework
- 🎤 **Voice Recognition**: Speech-to-text input
- 🔊 **Text-to-Speech**: AI responses spoken aloud
- 🧠 **Smart Responses**: Context-aware conversational AI
- 💬 **Empathetic Conversations**: Focused on addressing loneliness
- 🎨 **Beautiful UI**: Modern, calming interface
- 🔒 **Private**: No external API calls, no data storage
- 💯 **100% Free**: No API keys or costs required

## 📋 Prerequisites

- Python 3.7 or higher
- pip (Python package manager)

### Check if Python is installed:

**Windows:**
```bash
python --version
```

**Mac/Linux:**
```bash
python3 --version
```

If not installed, download from: https://www.python.org/downloads/

## 🚀 Installation & Setup

### Step 1: Extract the Files

Extract the folder and open a terminal/command prompt in that directory.

### Step 2: Create a Virtual Environment (Recommended)

**Windows:**
```bash
python -m venv venv
venv\Scripts\activate
```

**Mac/Linux:**
```bash
python3 -m venv venv
source venv/bin/activate
```

You should see `(venv)` appear in your terminal prompt.

### Step 3: Install Dependencies

```bash
pip install -r requirements.txt
```

This will install Flask and other required packages.

### Step 4: Run the Application

```bash
python app.py
```

You should see:
```
🤖 AI Companion Server Starting...
📱 Open your browser and go to: http://localhost:5000
```

### Step 5: Open in Browser

Open your web browser and go to:
```
http://localhost:5000
```

That's it! You're ready to chat! 🎉

## 💬 How to Use

### Text Chat
1. Type your message in the input box
2. Press Enter or click "Send"
3. The AI will respond with empathetic, thoughtful messages

### Voice Input
1. Click the microphone button (🎤)
2. Speak your message clearly
3. The button turns red while listening
4. Your speech is converted to text
5. Click "Send" to submit

### Voice Output
- AI responses are automatically spoken aloud
- Adjust your device volume as needed

## 🛑 Stopping the Server

Press `Ctrl + C` in the terminal to stop the Flask server.

## 🎨 Customization

### Modify AI Responses

Edit `app.py` and find the `ConversationAI` class. You can:
- Add new response categories
- Modify existing responses
- Change conversation patterns
- Adjust keyword detection

Example:
```python
self.responses = {
    'greetings': [
        "Your custom greeting here!",
        # Add more...
    ],
    # ... other categories
}
```

### Change UI Colors

Edit `templates/index.html` and modify the CSS:
```css
background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
/* Change these hex colors to your preference */
```

### Add New Features

The Flask app structure makes it easy to add:
- User authentication
- Database storage for conversations
- More sophisticated NLP
- Additional API endpoints

## 📁 Project Structure

```
ai-companion-python/
├── app.py                  # Main Flask application
├── requirements.txt        # Python dependencies
├── templates/
│   └── index.html         # Web interface
└── README.md              # This file
```

## 🔧 Advanced Configuration

### Change Port

Edit `app.py` at the bottom:
```python
app.run(debug=True, host='0.0.0.0', port=5000)  # Change 5000 to your preferred port
```

### Enable/Disable Debug Mode

```python
app.run(debug=False)  # Set to False for production
```

### Run on Network

The app is already configured to accept connections from other devices on your network:
```python
host='0.0.0.0'  # Allows external connections
```

Find your local IP address and access from other devices:
- Windows: `ipconfig`
- Mac/Linux: `ifconfig` or `ip addr`

Then visit: `http://YOUR_IP_ADDRESS:5000`

## 🆘 Troubleshooting

### "Python not found"
- Install Python from python.org
- Make sure Python is added to PATH during installation

### "pip not found"
```bash
python -m ensurepip --upgrade
```

### "ModuleNotFoundError: No module named 'flask'"
- Make sure you activated the virtual environment
- Run: `pip install -r requirements.txt`

### "Address already in use"
- Another program is using port 5000
- Change the port in `app.py` (see Advanced Configuration)

### Voice recognition not working
- Use Google Chrome for best compatibility
- Allow microphone permissions when prompted
- Check your microphone settings

### Port 5000 already in use
```bash
# Find what's using port 5000
# Windows:
netstat -ano | findstr :5000

# Mac/Linux:
lsof -i :5000

# Then change port in app.py
```

## 🌟 Features Explained

### Conversation Context
The AI maintains context including:
- Topics discussed (loneliness, work, hobbies, etc.)
- User's mood (detected from language)
- User's name (if shared)
- Conversation depth

### Response Categories
- **Greetings**: Welcome messages
- **Loneliness Support**: Empathetic responses to isolation
- **Activity Suggestions**: Ideas for meeting people
- **Mental Health**: Supportive responses, therapy suggestions
- **Encouragement**: Positive reinforcement
- **And more!**

### Smart Detection
The AI detects:
- Keywords and topics
- Emotional tone
- Questions vs statements
- Gratitude expressions
- User name introductions

## 🔐 Privacy & Security

- ✅ No external API calls
- ✅ No data sent to servers
- ✅ Conversations not stored permanently
- ✅ Runs entirely on your local machine
- ✅ No tracking or analytics

## 💡 Future Enhancements

You can extend this app with:

1. **Database Storage**
   ```bash
   pip install SQLAlchemy
   # Add conversation history persistence
   ```

2. **User Authentication**
   ```bash
   pip install Flask-Login
   # Add user accounts
   ```

3. **Advanced NLP**
   ```bash
   pip install spacy
   # Better language understanding
   ```

4. **Sentiment Analysis**
   ```bash
   pip install textblob
   # Detect emotions more accurately
   ```

5. **Export Conversations**
   - Add PDF/text export functionality
   - Save important insights

## 📚 Learning Resources

Want to understand or modify the code?

- **Flask Tutorial**: https://flask.palletsprojects.com/tutorial/
- **Python Basics**: https://www.python.org/about/gettingstarted/
- **Web Speech API**: https://developer.mozilla.org/en-US/docs/Web/API/Web_Speech_API

## 🤝 Contributing

Feel free to modify and improve this application! Some ideas:
- Add more response variations
- Improve keyword detection
- Add more conversation topics
- Enhance the UI
- Add new features

## ⚠️ Important Notes

This AI companion is designed to:
- Provide emotional support
- Encourage real-world connections
- Suggest practical activities
- Be a listening ear

It is **NOT** a replacement for:
- Professional therapy or counseling
- Medical advice
- Crisis intervention
- Human relationships

**If you're in crisis:**
- National Suicide Prevention Lifeline: 988
- Crisis Text Line: Text HOME to 741741
- Or call your local emergency services

## 📝 License

This project is open source and free to use, modify, and distribute.

## 🙏 Acknowledgments

Built with:
- Python & Flask
- Web Speech API
- Love and care for mental health

---

**Remember**: This tool is here to support you on your journey to connection, but real relationships and professional support are irreplaceable. Take care of yourself! 💙

For questions or issues, check the Troubleshooting section above.
