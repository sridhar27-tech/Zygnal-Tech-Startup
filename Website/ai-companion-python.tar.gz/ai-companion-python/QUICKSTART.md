# Quick Start Guide - AI Companion (Python)

## Super Fast Setup (3 Minutes)

### 1. Open Terminal/Command Prompt
- **Windows**: Press `Win + R`, type `cmd`, press Enter
- **Mac**: Press `Cmd + Space`, type `terminal`, press Enter
- **Linux**: Press `Ctrl + Alt + T`

### 2. Navigate to the Project Folder
```bash
cd path/to/ai-companion-python
```
(Replace `path/to` with where you saved the folder)

### 3. Install Dependencies
```bash
pip install -r requirements.txt
```
Wait 10-30 seconds...

### 4. Run the App
```bash
python app.py
```

### 5. Open Browser
Go to: **http://localhost:5000**

**Done! Start chatting!** 🎉

---

## Using Virtual Environment (Recommended)

### Windows:
```bash
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

### Mac/Linux:
```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
python app.py
```

---

## Common Issues

**Problem**: "Python not found"
**Solution**: Install Python from https://www.python.org/

**Problem**: "pip not found"
**Solution**: Run `python -m ensurepip --upgrade`

**Problem**: "Module not found"
**Solution**: Make sure you ran `pip install -r requirements.txt`

**Problem**: "Port 5000 in use"
**Solution**: Change port in `app.py` to 5001 or 8000

---

## Features

✅ Type or speak your messages
✅ AI responds with empathy
✅ Voice output (AI speaks back)
✅ Beautiful interface
✅ 100% Free, no API keys needed

---

## Stop the Server

Press **Ctrl + C** in terminal

---

## Next Steps

Read the full **README.md** for:
- Customization options
- Adding features
- Troubleshooting
- Privacy details

Enjoy your AI companion! 💙
