from flask import Flask, render_template, request, jsonify
import random
import re
from datetime import datetime

app = Flask(__name__)

# Conversation context storage (in-memory for simplicity)
conversation_contexts = {}

class ConversationAI:
    def __init__(self):
        self.context = {
            'topics': [],
            'mood': 'neutral',
            'user_name': None,
            'conversation_depth': 0,
            'mentioned_activities': [],
            'last_topic': None
        }
        
        # Response templates organized by category
        self.responses = {
            'greetings': [
                "Hello! I'm really glad you're here. How are you feeling today?",
                "Hi there! It's nice to meet you. What's on your mind?",
                "Hey! Thanks for stopping by. How can I support you today?",
                "Welcome! I'm here to listen. How are things going for you?"
            ],
            
            'loneliness': [
                "I hear you - feeling lonely can be really tough. Would you like to talk about what's making you feel this way? Sometimes just sharing can help.",
                "Loneliness is something many people struggle with, and it's brave of you to talk about it. What do you think might help you feel more connected?",
                "I'm here to listen. Feeling alone is difficult. Have you thought about small steps you could take to build connections, like joining a local group or reaching out to someone?",
                "It takes courage to acknowledge loneliness. You're not alone in feeling this way. What aspects of connection are you missing most?"
            ],
            
            'hobbies': [
                "That's interesting! Hobbies are a great way to meet like-minded people. Have you considered joining a club or online community around that interest?",
                "I love that you have interests you're passionate about! Have you shared this hobby with others? It could be a great conversation starter.",
                "That sounds engaging! Activities like that can be wonderful ways to connect with people who share your interests.",
                "Having hobbies is so important! Have you looked into local groups or meetups related to this interest?"
            ],
            
            'work_career': [
                "Work can be both rewarding and challenging. How do you feel about your work relationships? Sometimes workplace connections can develop into friendships.",
                "I understand - work takes up a lot of our time. Do you have opportunities to connect with colleagues outside of work tasks?",
                "Career stuff can be stressful. Are there ways you might build stronger connections with people at work?",
                "Your work life matters. Have you tried having lunch with colleagues or joining any work social events?"
            ],
            
            'family': [
                "Family relationships can be complex. How are things with your family right now?",
                "Family is important. Do you feel you can talk openly with your family members?",
                "I hear you talking about family. Those relationships can really impact how we feel day to day.",
                "Family dynamics can be challenging. How would you like your family relationships to be different?"
            ],
            
            'mental_health': [
                "I'm here for you. Remember, it's okay to not be okay sometimes. What would be most helpful for you right now?",
                "You're not alone in feeling this way. Have you considered talking to a professional counselor? They can provide really valuable support.",
                "I appreciate you opening up to me. While I'm here to chat, sometimes speaking with a trained therapist can make a real difference. Would you be open to that?",
                "Taking care of your mental health is so important. Have you reached out to any mental health resources? I can help you think through options."
            ],
            
            'encouragement': [
                "That's a great attitude! Small steps really do add up. What's one thing you could do this week to move forward?",
                "I'm glad to hear you're thinking positively! What specific actions are you considering?",
                "That's wonderful! Keep that momentum going. What's your next step?",
                "I love your positive energy! How can you build on this feeling?"
            ],
            
            'relationships': [
                "Relationships take work and vulnerability. How do you feel about reaching out to people?",
                "Building friendships as an adult can be challenging. What makes it hard for you to connect with others?",
                "Meaningful connections start with small steps. Have you tried joining any groups or activities where you might meet people?",
                "It's normal to want deeper connections. What kind of friendships are you looking for?"
            ],
            
            'activities_suggestions': [
                "Have you thought about joining a sports league, book club, or volunteering? These are great ways to meet people naturally.",
                "Sometimes structured activities like classes or meetup groups can make it easier to connect. What interests you?",
                "Local community centers often have events and groups. Have you checked what's available in your area?",
                "Online communities can be a good starting point too. What topics or activities interest you most?"
            ],
            
            'questions': [
                "That's a great question. What are your thoughts on it? I'd love to hear your perspective.",
                "Hmm, that's something to think about. How do you feel about it?",
                "Interesting question! What led you to wonder about that?",
                "I'm curious - what do you think the answer might be?"
            ],
            
            'gratitude': [
                "You're very welcome! I'm here whenever you need to talk.",
                "I'm glad I could help. Feel free to come back anytime!",
                "It's my pleasure. Remember, you're not alone in this journey.",
                "Thank you for sharing with me. You're doing great by reaching out."
            ],
            
            'default': [
                "I'm listening. Tell me more about that.",
                "I understand. How does that make you feel?",
                "Thanks for sharing that with me. What's been on your mind about this?",
                "I hear you. Would you like to explore that further?",
                "That sounds important to you. Can you tell me more?",
                "I appreciate you opening up. What else is on your mind?"
            ]
        }
        
        # Keyword patterns for detecting topics
        self.patterns = {
            'greeting': r'\b(hi|hello|hey|howdy|greetings|good morning|good evening)\b',
            'loneliness': r'\b(lonely|alone|isolated|nobody|no friends|no one|by myself)\b',
            'hobbies': r'\b(hobby|hobbies|interest|passion|enjoy|love doing|like to|play|read|game)\b',
            'work': r'\b(work|job|career|office|colleague|coworker|boss|employee)\b',
            'family': r'\b(family|parents|mom|dad|mother|father|brother|sister|siblings)\b',
            'sad': r'\b(sad|depressed|anxious|worried|scared|afraid|hurt|pain|down|upset)\b',
            'happy': r'\b(good|great|better|happy|glad|excited|awesome|wonderful|fantastic)\b',
            'thanks': r'\b(thank|thanks|appreciate|grateful)\b',
            'relationships': r'\b(friend|friends|relationship|dating|partner|social|connect|meet people)\b',
            'name_intro': r"(?:my name is|i'm|i am|call me)\s+([a-zA-Z]+)",
        }
    
    def extract_name(self, message):
        """Extract user's name if they introduce themselves"""
        match = re.search(self.patterns['name_intro'], message, re.IGNORECASE)
        if match:
            self.context['user_name'] = match.group(1).capitalize()
            return True
        return False
    
    def analyze_message(self, message):
        """Analyze the message and update context"""
        message_lower = message.lower()
        
        # Extract name
        self.extract_name(message)
        
        # Detect topics and mood
        detected_topics = []
        
        if re.search(self.patterns['loneliness'], message_lower):
            detected_topics.append('loneliness')
            self.context['mood'] = 'empathetic'
        
        if re.search(self.patterns['hobbies'], message_lower):
            detected_topics.append('hobbies')
        
        if re.search(self.patterns['work'], message_lower):
            detected_topics.append('work')
        
        if re.search(self.patterns['family'], message_lower):
            detected_topics.append('family')
        
        if re.search(self.patterns['sad'], message_lower):
            detected_topics.append('mental_health')
            self.context['mood'] = 'supportive'
        
        if re.search(self.patterns['happy'], message_lower):
            self.context['mood'] = 'positive'
        
        if re.search(self.patterns['relationships'], message_lower):
            detected_topics.append('relationships')
        
        # Update context
        for topic in detected_topics:
            if topic not in self.context['topics']:
                self.context['topics'].append(topic)
        
        self.context['conversation_depth'] += 1
        if detected_topics:
            self.context['last_topic'] = detected_topics[0]
        
        return detected_topics
    
    def generate_response(self, message):
        """Generate an appropriate response based on message analysis"""
        message_lower = message.lower()
        topics = self.analyze_message(message)
        
        # Determine response category
        response_category = None
        
        # Check for specific patterns in order of priority
        if re.search(self.patterns['greeting'], message_lower) and self.context['conversation_depth'] <= 2:
            response_category = 'greetings'
        elif re.search(self.patterns['thanks'], message_lower):
            response_category = 'gratitude'
        elif 'loneliness' in topics:
            response_category = 'loneliness'
        elif 'mental_health' in topics:
            response_category = 'mental_health'
        elif 'relationships' in topics:
            response_category = 'relationships'
        elif 'hobbies' in topics:
            response_category = 'hobbies'
        elif 'work' in topics:
            response_category = 'work_career'
        elif 'family' in topics:
            response_category = 'family'
        elif self.context['mood'] == 'positive':
            response_category = 'encouragement'
        elif '?' in message:
            response_category = 'questions'
        else:
            response_category = 'default'
        
        # Occasionally suggest activities if loneliness is a recurring topic
        if 'loneliness' in self.context['topics'] and self.context['conversation_depth'] > 3:
            if random.random() > 0.6:
                response_category = 'activities_suggestions'
        
        # Get response from selected category
        response = random.choice(self.responses[response_category])
        
        # Personalize with name occasionally
        if self.context['user_name'] and random.random() > 0.7:
            # Add name naturally to response
            if not response.startswith(self.context['user_name']):
                response = f"{self.context['user_name']}, {response[0].lower()}{response[1:]}"
        
        return response

# Global AI instance
ai = ConversationAI()

@app.route('/')
def index():
    """Serve the main page"""
    return render_template('index.html')

@app.route('/api/chat', methods=['POST'])
def chat():
    """Handle chat messages"""
    try:
        data = request.json
        user_message = data.get('message', '').strip()
        
        if not user_message:
            return jsonify({'error': 'Message is required'}), 400
        
        # Generate AI response
        ai_response = ai.generate_response(user_message)
        
        return jsonify({
            'response': ai_response,
            'timestamp': datetime.now().isoformat()
        })
    
    except Exception as e:
        print(f"Error: {e}")
        return jsonify({'error': 'Failed to generate response'}), 500

@app.route('/api/reset', methods=['POST'])
def reset_conversation():
    """Reset the conversation context"""
    global ai
    ai = ConversationAI()
    return jsonify({'status': 'reset', 'message': 'Conversation reset successfully'})

@app.route('/api/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({
        'status': 'healthy',
        'timestamp': datetime.now().isoformat()
    })

if __name__ == '__main__':
    print("=" * 50)
    print("🤖 AI Companion Server Starting...")
    print("=" * 50)
    print("📱 Open your browser and go to: http://localhost:5000")
    print("🎤 Features: Voice input/output, Smart responses")
    print("💡 No API keys needed - 100% Free!")
    print("=" * 50)
    app.run(debug=True, host='0.0.0.0', port=5000)
